# from django.contrib import admin
# from Franchise.models import Batch

# @admin.register(Batch)
# class BatchAdmin(admin.ModelAdmin):
#     list_display = ("id", "name", "course", "start_date", "end_date", "created_at")
#     search_fields = ("name", "course")
#     list_filter = ("course", "start_date")
#     ordering = ("-created_at",)
# # 