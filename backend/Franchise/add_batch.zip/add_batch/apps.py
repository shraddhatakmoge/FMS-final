from django.apps import AppConfig

class AddBatchConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Franchise.add_batch'
